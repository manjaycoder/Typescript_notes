let favNumber: number = 7;
favNumber += 2;

console.log(favNumber);

// ERROR
// favNumber = "eleven";
