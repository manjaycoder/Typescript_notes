let tsHard: boolean = false;
console.log(tsHard);

// ERROR
// tsHard = 100;
// tsHard = "HuXn";
