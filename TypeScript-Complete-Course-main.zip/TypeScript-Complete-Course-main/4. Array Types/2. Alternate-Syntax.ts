const items: Array<string> = [];
// const items: string[] = [];

const items2: Array<number> = [];
// const items2: numbers[] = []
