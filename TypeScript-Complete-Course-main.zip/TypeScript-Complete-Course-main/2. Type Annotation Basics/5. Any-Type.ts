let color: any = "crimson";
color = 20;
color = true;
color();
color.toUpperCase();
console.log(color);
