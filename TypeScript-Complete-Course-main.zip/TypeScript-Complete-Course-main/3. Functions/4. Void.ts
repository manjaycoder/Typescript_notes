function printMessage(message: string): void {
  console.log(`This is my message: ${message}`);
  // ERROR 👇
  // return message;
}

printMessage("Hello How Are You?");
