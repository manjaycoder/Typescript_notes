// let myVar: type = value

let myName: string = "HuXn WebDev";
myName = "Another Name";
console.log(myName);

// ERROR
// myName = 12;
